// Wayza — lógica de la página (versión HTML/CSS/JS sin framework).
// Los precios en vivo del sitio publicado vienen de un servidor (el token del proveedor
// no puede estar en el navegador). Esta versión estática genera precios estimados en dólares (USD)
// de forma determinista a partir de la búsqueda.

;(function () {
  'use strict'

  // ---------- Datos ----------

  var inspirations = [
    {
      title: 'Playas paradisíacas',
      description: 'Disfruta del sol y el mar en tus próximas vacaciones.',
      image: 'img/playas.png',
      destination: 'Cancún',
    },
    {
      title: 'Escapadas urbanas',
      description: 'Explora la cultura, la arquitectura y gastronomía local.',
      image: 'img/urbanas.png',
      destination: 'Nueva York',
    },
    {
      title: 'Grandes aventuras',
      description: 'Conecta con la naturaleza en montañas y parques naturales.',
      image: 'img/aventuras.png',
      destination: 'Banff',
    },
  ]

  var airlines = ['Avianca', 'LATAM', 'Copa Airlines', 'Iberia']
  var hotelNames = [
    'Hotel Brisa Azul',
    'Casa Central Boutique',
    'Gran Hotel Mirador',
    'Suites del Parque',
  ]
  var cars = [
    { name: 'Kia Picanto', type: 'Económico', seats: 4 },
    { name: 'Toyota Corolla', type: 'Intermedio', seats: 5 },
    { name: 'Mazda CX-5', type: 'SUV', seats: 5 },
    { name: 'Chevrolet Tahoe', type: 'Premium', seats: 7 },
  ]

  var labels = {
    vuelos: {
      destination: 'Destino',
      start: 'Ida',
      end: 'Vuelta',
      placeholder: '¿A dónde vas?',
    },
    hoteles: {
      destination: 'Destino',
      start: 'Entrada',
      end: 'Salida',
      placeholder: '¿A dónde vas?',
    },
    autos: {
      destination: 'Lugar de recogida',
      start: 'Recogida',
      end: 'Devolución',
      placeholder: '¿Dónde recoges el auto?',
    },
  }
  var headings = { vuelos: 'Vuelos', hoteles: 'Hoteles', autos: 'Autos' }

  var icons = {
    vuelos:
      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/></svg>',
    hoteles:
      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 21V7l9-4 9 4v14M9 21v-6h6v6M8 10h.01M12 10h.01M16 10h.01"/></svg>',
    autos:
      '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 17h14M5 17a2 2 0 1 1-4 0v-5l2-5h18l2 5v5a2 2 0 1 1-4 0M7 17a2 2 0 1 0 4 0M13 17a2 2 0 1 0 4 0M3 12h18"/></svg>',
  }

  // ---------- Utilidades ----------

  var money = new Intl.NumberFormat('es-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  })
  var dateFmt = new Intl.DateTimeFormat('es', {
    day: 'numeric',
    month: 'short',
  })

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (c) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
      }[c]
    })
  }

  function formatDate(value) {
    return value ? dateFmt.format(new Date(value + 'T12:00:00')) : ''
  }

  // Número pseudoaleatorio determinista: la misma búsqueda muestra los mismos resultados.
  function seeded(input) {
    var h = 2166136261
    for (var i = 0; i < input.length; i++) {
      h ^= input.charCodeAt(i)
      h = Math.imul(h, 16777619)
    }
    return function () {
      h = Math.imul(h ^ (h >>> 15), 2246822507)
      h = Math.imul(h ^ (h >>> 13), 3266489909)
      return ((h ^= h >>> 16) >>> 0) / 4294967296
    }
  }

  function nights(start, end) {
    var diff = (new Date(end).getTime() - new Date(start).getTime()) / 86400000
    return isFinite(diff) && diff > 0 ? Math.round(diff) : 1
  }

  function time(minutes) {
    var h = Math.floor(minutes / 60) % 24
    var m = minutes % 60
    return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0')
  }

  function plural(n, one, many) {
    return n + ' ' + (n === 1 ? one : many)
  }

  // ---------- Búsqueda (precios estimados en USD) ----------

  function searchTravel(q) {
    var rand = seeded(JSON.stringify(q))

    if (q.mode === 'vuelos') {
      return airlines.map(function (airline, i) {
        var depart = 360 + Math.floor(rand() * 14) * 60 + (i % 2) * 30
        var duration = 90 + Math.floor(rand() * 8) * 35
        var stops = rand() > 0.6 ? 1 : 0
        return {
          title: airline,
          subtitle: q.origin + ' → ' + q.destination,
          details: [
            time(depart) + ' – ' + time(depart + duration),
            Math.floor(duration / 60) + ' h ' + (duration % 60) + ' min',
            stops ? '1 escala' : 'Directo',
            q.end ? 'Ida y vuelta' : 'Solo ida',
          ],
          price: Math.round(120 + rand() * 480),
          priceLabel: 'por pasajero',
          badge: i === 0 ? 'Mejor precio' : stops ? '' : 'Más rápido',
        }
      })
    }

    if (q.mode === 'hoteles') {
      var n = nights(q.start, q.end)
      return hotelNames.map(function (name, i) {
        return {
          title: name,
          subtitle: q.destination,
          details: [
            (4 + rand()).toFixed(1) + ' ★',
            plural(n, 'noche', 'noches'),
            rand() > 0.5 ? 'Desayuno incluido' : 'Cancelación gratis',
            (0.3 + rand() * 4).toFixed(1) + ' km del centro',
          ],
          price: Math.round(60 + rand() * 240),
          priceLabel: 'por noche',
          badge: i === 1 ? 'Favorito de viajeros' : '',
        }
      })
    }

    var days = nights(q.start, q.end)
    return cars.map(function (car, i) {
      return {
        title: car.name,
        subtitle: car.type + ' · Recogida en ' + q.destination,
        details: [
          car.seats + ' pasajeros',
          rand() > 0.4 ? 'Automático' : 'Manual',
          'Kilometraje ilimitado',
          plural(days, 'día', 'días'),
        ],
        price: Math.round(25 + i * 22 + rand() * 20),
        priceLabel: 'por día',
        badge: i === 0 ? 'Más económico' : '',
      }
    })
  }

  // ---------- Estado y elementos ----------

  var mode = 'vuelos'
  var form = document.getElementById('search-form')
  var fields = document.getElementById('fields')
  var resultsEl = document.getElementById('resultados')
  var inputs = {
    origin: document.getElementById('search-origin'),
    destination: document.getElementById('search-destination'),
    start: document.getElementById('search-start'),
    end: document.getElementById('search-end'),
  }
  var today = new Date().toISOString().slice(0, 10)
  inputs.start.min = today
  inputs.end.min = today

  // ---------- Notificaciones ----------

  function toast(title, description) {
    var el = document.createElement('div')
    el.className = 'toast'
    el.innerHTML =
      '<strong>' +
      escapeHtml(title) +
      '</strong><span>' +
      escapeHtml(description) +
      '</span>'
    document.getElementById('toasts').appendChild(el)
    setTimeout(function () {
      el.remove()
    }, 4000)
  }

  // ---------- Formulario ----------

  function setError(key, message) {
    var input = inputs[key]
    var error = document.getElementById('search-' + key + '-error')
    error.textContent = message || ''
    error.hidden = !message
    if (message) {
      input.setAttribute('aria-invalid', 'true')
      input.setAttribute('aria-describedby', error.id)
    } else {
      input.removeAttribute('aria-invalid')
      input.removeAttribute('aria-describedby')
    }
  }

  function clearErrors() {
    Object.keys(inputs).forEach(function (key) {
      setError(key, '')
    })
  }

  function validate(v) {
    var errors = {}
    if (mode === 'vuelos' && !v.origin)
      errors.origin = 'Indica desde dónde sales'
    if (!v.destination)
      errors.destination =
        mode === 'autos' ? 'Indica dónde recoges el auto' : 'Indica a dónde vas'
    if (!v.start) errors.start = 'Elige una fecha'
    if (mode !== 'vuelos' && !v.end) errors.end = 'Elige una fecha'
    if (v.start && v.end && v.end < v.start)
      errors.end = 'Debe ser posterior a la primera fecha'
    if (
      mode === 'vuelos' &&
      v.origin &&
      v.origin.toLowerCase() === v.destination.toLowerCase()
    )
      errors.destination = 'El destino debe ser distinto al origen'
    return errors
  }

  function setMode(next) {
    mode = next
    document.querySelectorAll('.tab').forEach(function (tab) {
      tab.setAttribute('aria-selected', String(tab.dataset.mode === mode))
    })
    var text = labels[mode]
    document.querySelector('[data-field="origin"]').hidden = mode !== 'vuelos'
    fields.classList.toggle('no-origin', mode !== 'vuelos')
    document.getElementById('label-destination').textContent = text.destination
    document.getElementById('label-start').textContent = text.start
    document.getElementById('label-end').textContent = text.end
    inputs.destination.placeholder = text.placeholder
    clearErrors()
  }

  function focusSearch(field) {
    document
      .getElementById('buscar')
      .scrollIntoView({ behavior: 'smooth', block: 'center' })
    setTimeout(function () {
      inputs[field].focus({ preventScroll: true })
    }, 300)
  }

  Object.keys(inputs).forEach(function (key) {
    inputs[key].addEventListener('input', function () {
      setError(key, '')
      if (key === 'start') inputs.end.min = inputs.start.value || today
    })
  })

  document.querySelectorAll('.tab').forEach(function (tab) {
    tab.addEventListener('click', function () {
      setMode(tab.dataset.mode)
    })
  })

  form.addEventListener('submit', function (e) {
    e.preventDefault()
    var values = {
      mode: mode,
      origin: inputs.origin.value.trim(),
      destination: inputs.destination.value.trim(),
      start: inputs.start.value,
      end: inputs.end.value,
    }
    if (mode !== 'vuelos') values.origin = ''
    var errors = validate(values)
    clearErrors()
    Object.keys(errors).forEach(function (key) {
      setError(key, errors[key])
    })
    if (Object.keys(errors).length === 0) runSearch(values)
  })

  // ---------- Resultados ----------

  function renderHead(q) {
    var range = [formatDate(q.start), formatDate(q.end)]
      .filter(Boolean)
      .join(' – ')
    return (
      '<div><h2>' +
      headings[q.mode] +
      ' en ' +
      escapeHtml(q.destination) +
      '</h2><p>' +
      (q.mode === 'vuelos' ? 'Desde ' + escapeHtml(q.origin) + ' · ' : '') +
      range +
      '</p></div>'
    )
  }

  function runSearch(q) {
    resultsEl.hidden = false
    var skeleton = ''
    for (var i = 0; i < 3; i++) {
      skeleton +=
        '<li class="result"><div class="skeleton" style="width:3rem;height:3rem"></div>' +
        '<div class="result-body"><div class="skeleton" style="height:1rem;width:10rem;margin-bottom:.5rem"></div>' +
        '<div class="skeleton" style="height:.75rem;width:16rem;max-width:100%"></div></div>' +
        '<div class="skeleton" style="height:2.5rem;width:6rem"></div></li>'
    }
    resultsEl.innerHTML =
      '<div class="results-head">' +
      renderHead(q) +
      '</div><ul class="result-list" aria-label="Cargando resultados">' +
      skeleton +
      '</ul>'
    resultsEl.scrollIntoView({ behavior: 'smooth', block: 'start' })

    setTimeout(function () {
      renderResults(q, searchTravel(q))
    }, 600)
  }

  function renderResults(q, results) {
    var head =
      '<div class="results-head">' +
      renderHead(q) +
      '<div class="results-meta"><span class="badge">Precios estimados</span><span>' +
      results.length +
      ' opciones encontradas</span></div></div>' +
      '<p class="notice">Precios estimados en dólares estadounidenses (USD).</p>'

    if (results.length === 0) {
      resultsEl.innerHTML =
        head +
        '<div class="empty"><strong>No encontramos opciones para esta búsqueda</strong>' +
        '<span class="muted">Prueba con otras fechas o destino.</span></div>'
      return
    }

    var items = results
      .map(function (r, i) {
        return (
          '<li class="result"><div class="result-icon">' +
          icons[q.mode] +
          '</div><div class="result-body"><div class="result-title"><h3>' +
          escapeHtml(r.title) +
          '</h3>' +
          (r.badge
            ? '<span class="badge badge-soft">' + r.badge + '</span>'
            : '') +
          '</div><p class="result-sub">' +
          escapeHtml(r.subtitle) +
          '</p><p class="result-details">' +
          r.details
            .map(function (d) {
              return '<span>' + escapeHtml(d) + '</span>'
            })
            .join('') +
          '</p></div><div class="result-price"><p><span class="price">' +
          money.format(r.price) +
          '</span><span class="price-label">' +
          r.priceLabel +
          '</span></p><button type="button" class="btn btn-primary btn-sm" data-select="' +
          i +
          '">Seleccionar</button></div></li>'
        )
      })
      .join('')

    resultsEl.innerHTML = head + '<ul class="result-list">' + items + '</ul>'
    resultsEl.querySelectorAll('[data-select]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var r = results[Number(btn.dataset.select)]
        toast(
          r.title + ' seleccionado',
          'Te llevaremos al pago cuando las reservas estén disponibles.',
        )
      })
    })
  }

  // ---------- Inspiración ----------

  var cardsEl = document.getElementById('cards')
  inspirations.forEach(function (item) {
    var li = document.createElement('li')
    li.innerHTML =
      '<button type="button" class="card"><div class="card-img"><img src="' +
      item.image +
      '" alt="" loading="lazy" /></div><div class="card-body"><h3>' +
      item.title +
      '</h3><p>' +
      item.description +
      '</p><p class="card-link">Ver ofertas en ' +
      item.destination +
      ' →</p></div></button>'
    li.querySelector('button').addEventListener('click', function () {
      inputs.destination.value = item.destination
      setError('destination', '')
      focusSearch(
        mode === 'vuelos' && !inputs.origin.value ? 'origin' : 'start',
      )
    })
    cardsEl.appendChild(li)
  })

  // ---------- Encabezado, menú móvil e inicio de sesión ----------

  var menu = document.getElementById('mobile-menu')
  var menuButton = document.getElementById('open-menu')
  menuButton.addEventListener('click', function () {
    menu.hidden = !menu.hidden
    menuButton.setAttribute('aria-expanded', String(!menu.hidden))
    menuButton.setAttribute(
      'aria-label',
      menu.hidden ? 'Abrir menú' : 'Cerrar menú',
    )
  })

  document.querySelectorAll('[data-nav]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      menu.hidden = true
      menuButton.setAttribute('aria-expanded', 'false')
      var target = btn.dataset.nav
      if (target === 'explorar') {
        document
          .getElementById('explorar')
          .scrollIntoView({ behavior: 'smooth' })
        return
      }
      setMode(target)
      focusSearch(target === 'vuelos' ? 'origin' : 'destination')
    })
  })

  var dialog = document.getElementById('login-dialog')
  document.getElementById('open-login').addEventListener('click', function () {
    dialog.showModal()
  })
  document
    .getElementById('login-form')
    .addEventListener('submit', function (e) {
      e.preventDefault()
      dialog.close()
      toast(
        'Las cuentas de Wayza llegan muy pronto',
        'Mientras tanto, puedes buscar vuelos, hoteles y autos sin registrarte.',
      )
    })

  document.getElementById('year').textContent = new Date().getFullYear()
  setMode('vuelos')
})()
