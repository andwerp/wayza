# Wayza en HTML, CSS y JavaScript

Versión de la página de Wayza separada en tres archivos, sin framework ni paso de compilación:

- `index.html` — estructura de la página.
- `styles.css` — colores, tipografía y diseño.
- `script.js` — pestañas, validación del formulario, resultados, tarjetas de inspiración, menú móvil e inicio de sesión.
- `img/` — imágenes de las tarjetas.

Abre `index.html` en el navegador para verla. Los precios se muestran en dólares (USD). Como esta versión no tiene servidor, los resultados usan precios estimados; los precios en vivo del sitio publicado necesitan un servidor para mantener privada la clave del proveedor.
